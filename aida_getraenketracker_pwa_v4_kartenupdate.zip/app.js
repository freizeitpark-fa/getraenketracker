(() => {
'use strict';
const STORAGE_KEY = 'aida_getraenketracker_pwa_v3'; // bewusst stabil: vorhandene lokale Daten bleiben erhalten
const STATUS_LABEL = {included:'enthalten', excluded:'nicht enthalten', unclear:'unklar'};
const CATALOG_BASE_SOURCE = { name:'AIDA Barkarte', version:'Stand 01.11.2025', loadedAt:'2026-07-09', note:'Aus der hochgeladenen Barkarte als Stammkatalog übernommen.' };
const PACKAGE_IDS = ['none','all_in','fun','kids_all_in','kids_fun'];
let state = null;
let selectedCategory = 'Favoriten';
let editingEntryId = null;
let pendingCatalogImport = null;

const $ = id => document.getElementById(id);
const $$ = sel => Array.from(document.querySelectorAll(sel));
const nowIso = () => new Date().toISOString();
const today = () => new Date().toISOString().slice(0,10);
const eur = v => Number(v || 0).toLocaleString('de-DE',{style:'currency',currency:'EUR'});
const escapeHtml = s => String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const parseMoney = v => Number(String(v ?? '').replace(/\./g,'').replace(',', '.')) || 0;
const slug = s => String(s || 'reise').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,70) || 'reise';
const uid = prefix => prefix + '_' + (crypto.randomUUID ? crypto.randomUUID() : (Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,9)));
const shortId = id => String(id || '').replace(/^dev_/,'').slice(0,12);

function makeDefaultState(){
  const tripId = uid('trip');
  return {
    schemaVersion: 3,
    createdAt: nowIso(),
    updatedAt: nowIso(),
    device: { id: 'dev_' + (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)+Math.random().toString(36).slice(2)), name: '', recorderPersonId: '', setupDone: false },
    activeTripId: tripId,
    activePersonId: '',
    trips: [{ id: tripId, name: 'Neue Reise', start: '', end: '', status: 'active', people: [], entries: [], createdAt: nowIso(), updatedAt: nowIso() }],
    manualDrinks: [],
    catalogSource: Object.assign({}, CATALOG_BASE_SOURCE),
    catalogOverrides: {},
    catalogAdditions: [],
    lastCatalogDiff: null,
    importedExports: []
  };
}
function load(){
  try { state = JSON.parse(localStorage.getItem(STORAGE_KEY)) || makeDefaultState(); }
  catch(e){ state = makeDefaultState(); }
  migrate();
}
function migrate(){
  if(!state.device) state.device = {id:'dev_'+uid('x'), name:'', recorderPersonId:'', setupDone:false};
  if(!state.device.id) state.device.id = 'dev_' + uid('x');
  if(!state.trips || !state.trips.length){ const fresh=makeDefaultState(); state.trips=fresh.trips; state.activeTripId=fresh.activeTripId; }
  for(const t of state.trips){
    if(!t.people) t.people=[];
    if(!t.entries) t.entries=[];
    if(!t.status) t.status = t.closed ? 'closed' : 'active';
    for(const p of t.people){ if(!p.id) p.id=uid('p'); if(!p.packageId) p.packageId='none'; p.packagePrice=Number(p.packagePrice||0); }
    for(const e of t.entries){ if(!e.id) e.id=uid('e'); if(!e.updatedAt) e.updatedAt=e.at||nowIso(); if(!e.createdAt) e.createdAt=e.at||nowIso(); if(!e.sourceDeviceId) e.sourceDeviceId=state.device.id; }
  }
  if(!state.catalogSource) state.catalogSource = Object.assign({}, CATALOG_BASE_SOURCE);
  if(!state.catalogOverrides) state.catalogOverrides = {};
  if(!state.catalogAdditions) state.catalogAdditions = [];
  if(!state.lastCatalogDiff) state.lastCatalogDiff = null;
  if(!activeTrip()) state.activeTripId = state.trips[0].id;
  state.schemaVersion = 4;
}
function save(){ state.updatedAt = nowIso(); localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); render(); }
function toast(msg){ const t=$('toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toast._timer); toast._timer=setTimeout(()=>t.classList.remove('show'),2600); }
function downloadBlob(blob,name){ const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=name; document.body.appendChild(a); a.click(); setTimeout(()=>{URL.revokeObjectURL(a.href); a.remove();},800); }
function packageName(id){ return (AIDA_PACKAGES.find(p=>p.id===id)||AIDA_PACKAGES[0]).name; }
function packageOptions(selected='none'){ return AIDA_PACKAGES.map(p=>`<option value="${p.id}" ${p.id===selected?'selected':''}>${escapeHtml(p.name)}</option>`).join(''); }
function activeTrip(){ return state.trips.find(t=>t.id===state.activeTripId) || state.trips[0]; }
function normalizeKeyPart(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim(); }
function drinkKey(d){ return [normalizeKeyPart(d.category), normalizeKeyPart(d.name), normalizeKeyPart(d.size)].join('|'); }
function drinkNameSizeKey(d){ return [normalizeKeyPart(d.name), normalizeKeyPart(d.size)].join('|'); }
function cloneDrink(d){ return Object.assign({}, d, {packages:Object.assign({}, d.packages||{})}); }
function currentCatalog(includeArchived=false){
  const fav = state.favoriteOverrides || {};
  const overrides = state.catalogOverrides || {};
  const base = AIDA_DRINKS.map(src => {
    const d = cloneDrink(src);
    const ov = overrides[d.id];
    if(ov){ Object.assign(d, ov); d.packages = Object.assign({}, src.packages||{}, ov.packages||{}); }
    if(Object.prototype.hasOwnProperty.call(fav,d.id)) d.favorite = !!fav[d.id];
    return d;
  });
  const additions = (state.catalogAdditions || []).map(cloneDrink).map(d => { if(Object.prototype.hasOwnProperty.call(fav,d.id)) d.favorite = !!fav[d.id]; return d; });
  const merged = base.concat(additions);
  return includeArchived ? merged : merged.filter(d=>!d.archived);
}
function allDrinks(includeArchived=false){ return currentCatalog(includeArchived).concat(state.manualDrinks || []); }
function drinkById(id){ return allDrinks(true).find(d=>d.id===id); }
function personById(id,t=activeTrip()){ return t.people.find(p=>p.id===id); }
function currentPerson(){ const t=activeTrip(); return personById(state.activePersonId,t) || t.people[0] || null; }
function defaultRecorder(){ const t=activeTrip(); return personById(state.device.recorderPersonId,t) || currentPerson(); }
function isClosed(t=activeTrip()){ return t.status === 'closed'; }
function categories(){ return ['Favoriten', ...Array.from(new Set(allDrinks().map(d=>d.category))).sort((a,b)=>a.localeCompare(b,'de'))]; }
function statusFor(drink, person){
  if(!drink || !person) return 'unclear';
  const pkg = person.packageId || 'none';
  if(pkg === 'none') return 'excluded';
  return (drink.packages && drink.packages[pkg]) || 'unclear';
}
function calcTrip(t=activeTrip()){
  const rows=[]; const sums={total:0,covered:0,extra:0,unclear:0,packageCost:0};
  const perPerson = new Map(); const top = new Map(); const cats = new Map(); const days = new Map();
  for(const p of t.people){
    const obj = {person:p,total:0,covered:0,extra:0,unclear:0,packageCost:Number(p.packagePrice||0),net:null};
    perPerson.set(p.id,obj); sums.packageCost += obj.packageCost;
  }
  for(const e of t.entries.filter(x=>!x.deletedAt)){
    const p=personById(e.consumedByPersonId,t) || personById(e.personId,t);
    const d=drinkById(e.drinkId);
    if(!p || !d) continue;
    const qty=Number(e.quantity || e.qty || 1);
    const unit=Number(e.unitPrice ?? d.price ?? 0);
    const value=qty*unit;
    const status=statusFor(d,p);
    let covered=0,extra=0,unclear=0;
    if(status==='included') covered=value; else if(status==='excluded') extra=value; else unclear=value;
    rows.push({entry:e, person:p, drink:d, qty, unit, value, status, covered, extra, unclear});
    sums.total += value; sums.covered += covered; sums.extra += extra; sums.unclear += unclear;
    const pp=perPerson.get(p.id); if(pp){ pp.total += value; pp.covered += covered; pp.extra += extra; pp.unclear += unclear; }
    const topKey=d.name; const tv=top.get(topKey)||{qty:0,value:0}; tv.qty+=qty; tv.value+=value; top.set(topKey,tv);
    cats.set(d.category,(cats.get(d.category)||0)+value);
    days.set((e.at||e.createdAt||'').slice(0,10),(days.get((e.at||e.createdAt||'').slice(0,10))||0)+value);
  }
  for(const pp of perPerson.values()) pp.net = pp.packageCost ? pp.covered - pp.packageCost : null;
  return {rows, sums, people:Array.from(perPerson.values()), top:Array.from(top.entries()).sort((a,b)=>b[1].qty-a[1].qty).slice(0,10), cats:Array.from(cats.entries()).sort((a,b)=>b[1]-a[1]), days:Array.from(days.entries()).sort((a,b)=>a[0].localeCompare(b[0]))};
}

function showPage(name){
  $$('.page').forEach(p=>p.classList.remove('active'));
  const page=$('page-'+name); if(page) page.classList.add('active');
  $$('.tabs button').forEach(b=>b.classList.toggle('active', b.dataset.goto===name));
  render();
}
function render(){
  if(!state) return;
  const t=activeTrip();
  $('tripLine').innerHTML = `${escapeHtml(t.name)} ${isClosed(t)?'<span class="pill closed">abgeschlossen</span>':''}<br><span class="tiny">${escapeHtml(state.device.name || 'Gerät nicht eingerichtet')}</span>`;
  renderCapture(); renderReport(); renderEntries(); renderMaster(); renderCatalog();
  renderOnboardingIfNeeded();
}
function renderCapture(){
  const t=activeTrip(); const p=currentPerson(); const r=defaultRecorder();
  $('deviceLabel').textContent = state.device.name || 'nicht eingerichtet';
  $('recorderLabel').textContent = r ? r.name : 'nicht ausgewählt';
  $('peopleButtons').innerHTML = t.people.map(x=>`<button class="personBtn ${p&&p.id===x.id?'active':''}" data-person="${x.id}"><b>${escapeHtml(x.name)}</b><br><span class="tiny muted">${escapeHtml(packageName(x.packageId))}</span></button>`).join('') || '<div class="noData">Noch keine Personen. Bitte Stammdaten anlegen oder importieren.</div>';
  $('peopleButtons').querySelectorAll('[data-person]').forEach(btn=>btn.addEventListener('click',()=>{state.activePersonId=btn.dataset.person; save();}));
  const cats=categories(); if(!cats.includes(selectedCategory)) selectedCategory='Favoriten';
  $('categorySeg').innerHTML = cats.map(c=>`<button class="small ${selectedCategory===c?'active':''}" data-cat="${escapeHtml(c)}">${escapeHtml(c)}</button>`).join('');
  $('categorySeg').querySelectorAll('[data-cat]').forEach(btn=>btn.addEventListener('click',()=>{selectedCategory=btn.dataset.cat; renderCapture();}));
  const q=($('drinkSearch').value||'').toLowerCase().trim();
  let ds=allDrinks().filter(d => !q || (d.name+' '+d.category+' '+(d.size||'')).toLowerCase().includes(q));
  if(selectedCategory==='Favoriten') ds=ds.filter(d=>d.favorite); else ds=ds.filter(d=>d.category===selectedCategory);
  ds.sort((a,b)=>Number(b.favorite)-Number(a.favorite)||a.name.localeCompare(b.name,'de'));
  const favs=allDrinks().filter(d=>d.favorite && (!q || (d.name+' '+d.category+' '+(d.size||'')).toLowerCase().includes(q))).slice(0,16);
  $('favDrinks').innerHTML = drinkButtons(favs) || '<div class="noData">Keine Favoriten gefunden.</div>';
  $('allDrinks').innerHTML = drinkButtons(ds) || '<div class="noData">Keine Getränke gefunden.</div>';
  document.querySelectorAll('[data-drink]').forEach(btn=>btn.addEventListener('click',()=>addEntry(btn.dataset.drink)));
}
function drinkButtons(ds){ return ds.map(d=>`<button class="drinkBtn" data-drink="${d.id}"><div class="name">${escapeHtml(d.name)}</div><div class="price money">${eur(d.price)}${d.size?' · '+escapeHtml(d.size):''}</div><div class="cat">${escapeHtml(d.category)}</div></button>`).join(''); }
function addEntry(drinkId){
  const t=activeTrip(); if(isClosed(t)){ toast('Reise ist abgeschlossen.'); return; }
  const p=currentPerson(); const r=defaultRecorder(); const d=drinkById(drinkId);
  if(!p){ toast('Bitte zuerst eine Person anlegen oder auswählen.'); return; }
  if(!r){ toast('Bitte Standard-Erfasser im Gerät festlegen.'); return; }
  if(!d) return;
  const qty = Math.max(0.1, parseMoney($('qtyInput').value || '1') || 1);
  const at = nowIso();
  const e = { id: state.device.id + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,8), tripId:t.id, consumedByPersonId:p.id, recordedByPersonId:r.id, drinkId:d.id, quantity:qty, unitPrice:Number(d.price||0), packageIdAtBooking:p.packageId||'none', packageStatusAtBooking:statusFor(d,p), at, createdAt:at, updatedAt:at, deletedAt:null, sourceDeviceId:state.device.id, note:'' };
  t.entries.push(e); state.lastEntryId=e.id; save(); toast(`${p.name}: ${d.name} gespeichert.`);
}
function undoLast(){ const t=activeTrip(); const e=[...t.entries].reverse().find(x=>!x.deletedAt); if(!e){toast('Kein Eintrag vorhanden.'); return;} if(!confirm('Letzten Eintrag löschen?')) return; e.deletedAt=nowIso(); e.updatedAt=nowIso(); save(); toast('Letzter Eintrag gelöscht.'); }
function renderReport(){
  const {sums, people, top, cats, days}=calcTrip();
  const net = sums.packageCost ? sums.covered - sums.packageCost : null;
  const breakEven = sums.packageCost ? Math.max(0, sums.packageCost - sums.covered) : null;
  $('reportCards').innerHTML = `<div class="card"><h2>Auswertung aktive Reise</h2><div class="kpis"><div class="kpi"><span class="label">Barkartenwert gesamt</span><span class="value money">${eur(sums.total)}</span></div><div class="kpi"><span class="label">Vom Paket abgedeckt</span><span class="value money">${eur(sums.covered)}</span></div><div class="kpi"><span class="label">Zusatzkosten</span><span class="value money">${eur(sums.extra)}</span></div><div class="kpi"><span class="label">Unklar</span><span class="value money">${eur(sums.unclear)}</span></div><div class="kpi"><span class="label">Paketkosten</span><span class="value money">${eur(sums.packageCost)}</span></div><div class="kpi"><span class="label">Netto-Ersparnis</span><span class="value money">${net===null?'–':eur(net)}</span></div></div>${breakEven!==null?`<p class="hint">Break-even: ${breakEven>0?'Es fehlen noch <b class="money">'+eur(breakEven)+'</b> abgedeckter Konsumwert.':'Paket rechnerisch erreicht.'}</p>`:'<p class="muted">Ohne Paketpreis wird keine Netto-Ersparnis berechnet.</p>'}</div>` +
  `<div class="card"><h2>Pro Person</h2>${people.map(x=>`<div class="item"><div class="row"><div><b>${escapeHtml(x.person.name)}</b><br><span class="tiny muted">${escapeHtml(packageName(x.person.packageId))}</span></div><b class="money">${eur(x.total)}</b></div><div class="tiny muted">abgedeckt ${eur(x.covered)} · extra ${eur(x.extra)} · unklar ${eur(x.unclear)} · Paket ${eur(x.packageCost)} · Netto ${x.net===null?'–':eur(x.net)}</div></div>`).join('')||'<div class="noData">Keine Personen.</div>'}</div>` +
  `<div class="card"><h2>Top-Getränke</h2>${top.map(([n,v])=>`<div class="item row"><span>${escapeHtml(n)}<br><span class="tiny muted">${v.qty}x</span></span><b class="money">${eur(v.value)}</b></div>`).join('')||'<div class="noData">Noch keine Einträge.</div>'}</div>` +
  `<div class="card"><h2>Nach Kategorie</h2>${cats.map(([n,v])=>`<div class="item row"><span>${escapeHtml(n)}</span><b class="money">${eur(v)}</b></div>`).join('')||'<div class="noData">Noch keine Einträge.</div>'}</div>` +
  `<div class="card"><h2>Tagesübersicht</h2>${days.map(([n,v])=>`<div class="item row"><span>${escapeHtml(n)}</span><b class="money">${eur(v)}</b></div>`).join('')||'<div class="noData">Noch keine Einträge.</div>'}</div>`;
}
function renderEntries(){
  const q=($('entrySearch').value||'').toLowerCase().trim(); const {rows}=calcTrip();
  const filtered=rows.slice().reverse().filter(r=>!q || (r.person.name+' '+r.drink.name+' '+r.drink.category).toLowerCase().includes(q));
  $('entriesList').innerHTML = filtered.map(r=>entryHtml(r)).join('') || '<div class="card noData">Noch keine Einträge.</div>';
  $('entriesList').querySelectorAll('[data-edit-entry]').forEach(b=>b.addEventListener('click',()=>editEntry(b.dataset.editEntry)));
  $('entriesList').querySelectorAll('[data-del-entry]').forEach(b=>b.addEventListener('click',()=>deleteEntry(b.dataset.delEntry)));
}
function entryHtml(r){ const e=r.entry, recorder=personById(e.recordedByPersonId)||{name:'unbekannt'}; return `<div class="item"><div class="row"><div><b>${escapeHtml(r.person.name)}</b> · ${escapeHtml(r.drink.name)}<br><span class="tiny muted">${new Date(e.at||e.createdAt).toLocaleString('de-DE')} · erfasst durch ${escapeHtml(recorder.name)}</span></div><div class="right"><b class="money">${eur(r.value)}</b><br><span class="pill ${r.status}">${STATUS_LABEL[r.status]}</span></div></div><div class="tiny muted">Menge ${r.qty} · Einzelpreis ${eur(r.unit)}${e.note?' · '+escapeHtml(e.note):''}</div><div class="buttonRow"><button class="small" data-edit-entry="${e.id}">Bearbeiten</button><button class="small danger" data-del-entry="${e.id}">Löschen</button></div></div>`; }
function editEntry(id){ const t=activeTrip(); const e=t.entries.find(x=>x.id===id); if(!e)return; const q=prompt('Menge', String(e.quantity||1).replace('.',',')); if(q===null)return; const n=prompt('Notiz optional', e.note||''); if(n===null)return; e.quantity=Math.max(0.1,parseMoney(q)||1); e.note=n; e.updatedAt=nowIso(); save(); }
function deleteEntry(id){ const t=activeTrip(); const e=t.entries.find(x=>x.id===id); if(!e)return; if(!confirm('Eintrag wirklich löschen?'))return; e.deletedAt=nowIso(); e.updatedAt=nowIso(); save(); }
function renderMaster(){
  const t=activeTrip();
  $('deviceName').value = state.device.name || '';
  $('deviceRecorder').innerHTML = '<option value="">Bitte wählen</option>' + t.people.map(p=>`<option value="${p.id}" ${state.device.recorderPersonId===p.id?'selected':''}>${escapeHtml(p.name)}</option>`).join('');
  $('tripSelect').innerHTML = state.trips.map(x=>`<option value="${x.id}" ${x.id===t.id?'selected':''}>${escapeHtml(x.name)}${x.status==='closed'?' (abgeschlossen)':''}</option>`).join('');
  $('tripName').value=t.name||''; $('tripStart').value=t.start||''; $('tripEnd').value=t.end||''; $('tripStatus').value=t.status||'active';
  $('personPackage').innerHTML=packageOptions('none');
  $('peopleCount').textContent = `${t.people.length} Personen`;
  $('peopleAdmin').innerHTML = t.people.map(p=>`<div class="item" data-person-admin="${p.id}"><label class="lbl">Name</label><input class="input pa-name" value="${escapeHtml(p.name)}"><label class="lbl">Getränkepaket</label><select class="input pa-pkg">${packageOptions(p.packageId)}</select><label class="lbl">Paketpreis</label><input class="input pa-price" inputmode="decimal" value="${String(Number(p.packagePrice||0).toFixed(2)).replace('.',',')}"><div class="buttonRow"><button class="small primary" data-save-person="${p.id}">Speichern</button><button class="small danger" data-delete-person="${p.id}">Löschen</button></div></div>`).join('') || '<div class="noData">Noch keine Personen angelegt.</div>';
  $('peopleAdmin').querySelectorAll('[data-save-person]').forEach(b=>b.addEventListener('click',()=>updatePerson(b.dataset.savePerson)));
  $('peopleAdmin').querySelectorAll('[data-delete-person]').forEach(b=>b.addEventListener('click',()=>deletePerson(b.dataset.deletePerson)));
}
function saveDevice(){ state.device.name=$('deviceName').value.trim() || 'iPhone'; state.device.recorderPersonId=$('deviceRecorder').value; state.device.setupDone=!!state.device.recorderPersonId; save(); toast('Gerät gespeichert.'); }
function saveTrip(){ const t=activeTrip(); t.name=$('tripName').value.trim()||'Reise'; t.start=$('tripStart').value; t.end=$('tripEnd').value; t.status=$('tripStatus').value; t.updatedAt=nowIso(); save(); toast('Reise gespeichert.'); }
function switchTrip(){ state.activeTripId=$('tripSelect').value; const t=activeTrip(); state.activePersonId=t.people[0]?.id || ''; save(); }
function newTrip(){ const id=uid('trip'); state.trips.unshift({id,name:'Neue Reise',start:'',end:'',status:'active',people:[],entries:[],createdAt:nowIso(),updatedAt:nowIso()}); state.activeTripId=id; state.activePersonId=''; save(); showPage('master'); }
function closeTrip(){ const t=activeTrip(); if(!confirm('Reise als abgeschlossen markieren?'))return; t.status='closed'; t.updatedAt=nowIso(); save(); }
function addPerson(){ const t=activeTrip(); if(isClosed(t)){toast('Reise ist abgeschlossen.');return;} const name=$('personName').value.trim(); if(!name){toast('Name fehlt.');return;} const p={id:uid('p'), name, packageId:$('personPackage').value||'none', packagePrice:parseMoney($('personPackagePrice').value), createdAt:nowIso(), updatedAt:nowIso()}; t.people.push(p); if(!state.activePersonId) state.activePersonId=p.id; if(!state.device.recorderPersonId && state.device.name) state.device.recorderPersonId=p.id; $('personName').value=''; $('personPackagePrice').value=''; save(); toast('Person angelegt.'); }
function updatePerson(id){ const t=activeTrip(); const box=document.querySelector(`[data-person-admin="${id}"]`); const p=personById(id,t); if(!box||!p)return; p.name=box.querySelector('.pa-name').value.trim()||p.name; p.packageId=box.querySelector('.pa-pkg').value||'none'; p.packagePrice=parseMoney(box.querySelector('.pa-price').value); p.updatedAt=nowIso(); save(); toast('Person gespeichert.'); }
function deletePerson(id){ const t=activeTrip(); if(t.entries.some(e=>(e.consumedByPersonId===id || e.personId===id) && !e.deletedAt)){toast('Person hat Einträge und kann nicht gelöscht werden.');return;} if(!confirm('Person löschen?'))return; t.people=t.people.filter(p=>p.id!==id); if(state.activePersonId===id) state.activePersonId=t.people[0]?.id||''; if(state.device.recorderPersonId===id) state.device.recorderPersonId=''; save(); }

function renderCatalog(){
  const q=($('catalogSearch').value||'').toLowerCase().trim();
  const active=currentCatalog(false); const total=currentCatalog(true);
  const ds=allDrinks(true).filter(d=>!q||(d.name+' '+d.category+' '+(d.size||'')+' '+(d.note||'')+' '+(d.source||'')).toLowerCase().includes(q)).sort((a,b)=>String(a.category).localeCompare(String(b.category),'de')||String(a.name).localeCompare(String(b.name),'de'));
  $('catalogCount').textContent=`${active.length} aktiv / ${total.length} Katalog`;
  if($('catalogSourceInfo')) $('catalogSourceInfo').innerHTML = `Aktueller Stamm: <b>${escapeHtml(state.catalogSource?.name || 'AIDA Barkarte')}</b> · ${escapeHtml(state.catalogSource?.version || '')} · geladen ${escapeHtml(state.catalogSource?.loadedAt || '')}`;
  $('catalogList').innerHTML=ds.map(d=>`<div class="item ${d.archived?'deleted':''}"><div class="row"><div><b>${escapeHtml(d.name)}</b>${d.archived?' <span class="pill closed">nicht in aktueller Karte</span>':''}<br><span class="tiny muted">${escapeHtml(d.category)}${d.size?' · '+escapeHtml(d.size):''}${d.source?' · '+escapeHtml(d.source):''}</span></div><div class="right"><b class="money">${eur(d.price)}</b><br>${d.favorite?'★ Favorit':''}</div></div><div class="tiny" style="margin-top:8px">ALL IN ${statusPill(d.packages.all_in)} FUN ${statusPill(d.packages.fun)} Kids ALL IN ${statusPill(d.packages.kids_all_in)} Kids FUN ${statusPill(d.packages.kids_fun)}</div>${d.note?`<p class="tiny muted">${escapeHtml(d.note)}</p>`:''}<div class="buttonRow"><button class="small" data-fav="${d.id}">Favorit wechseln</button>${d.source==='manuell'?`<button class="small danger" data-del-drink="${d.id}">Löschen</button>`:''}</div></div>`).join('') || '<div class="card noData">Keine Getränke gefunden.</div>';
  $('catalogList').querySelectorAll('[data-fav]').forEach(b=>b.addEventListener('click',()=>toggleFav(b.dataset.fav)));
  $('catalogList').querySelectorAll('[data-del-drink]').forEach(b=>b.addEventListener('click',()=>deleteDrink(b.dataset.delDrink)));
  renderCatalogDiff();
}
function statusPill(s){ s=s||'unclear'; return `<span class="pill ${s}">${STATUS_LABEL[s]}</span>`; }
function toggleFav(id){ const d=drinkById(id); if(!d)return; state.favoriteOverrides = state.favoriteOverrides || {}; state.favoriteOverrides[id]=!d.favorite; const m=(state.manualDrinks||[]).find(x=>x.id===id); if(m) m.favorite=!d.favorite; const a=(state.catalogAdditions||[]).find(x=>x.id===id); if(a) a.favorite=!d.favorite; save(); }
function applyFavoriteOverrides(){ if(!state.favoriteOverrides)return; for(const d of AIDA_DRINKS){ if(Object.prototype.hasOwnProperty.call(state.favoriteOverrides,d.id)) d.favorite=!!state.favoriteOverrides[d.id]; }}
function addManualDrink(){ const name=$('newDrinkName').value.trim(); const category=$('newDrinkCategory').value.trim()||'Manuell'; const price=parseMoney($('newDrinkPrice').value); if(!name||!price){toast('Name und Preis erfassen.');return;} const s=$('newDrinkStatus').value; let packages={all_in:'unclear',fun:'unclear',kids_all_in:'unclear',kids_fun:'unclear'}; if(s==='excluded') packages={all_in:'excluded',fun:'excluded',kids_all_in:'excluded',kids_fun:'excluded'}; if(s==='all_in') packages={all_in:'included',fun:'excluded',kids_all_in:'excluded',kids_fun:'excluded'}; if(s==='all_in_fun') packages={all_in:'included',fun:'included',kids_all_in:'excluded',kids_fun:'excluded'}; if(s==='all_adult_kids_all_in') packages={all_in:'included',fun:'included',kids_all_in:'included',kids_fun:'excluded'}; if(s==='all_packages') packages={all_in:'included',fun:'included',kids_all_in:'included',kids_fun:'included'}; state.manualDrinks.push({id:uid('d'), name, category, price, size:'', packages, note:'manuell ergänzt', favorite:false, source:'manuell', createdAt:nowIso(), updatedAt:nowIso()}); $('newDrinkName').value=''; $('newDrinkCategory').value=''; $('newDrinkPrice').value=''; save(); toast('Getränk ergänzt.'); }
function deleteDrink(id){ const t=activeTrip(); if(t.entries.some(e=>e.drinkId===id && !e.deletedAt)){toast('Getränk hat Einträge und kann nicht gelöscht werden.');return;} if(!confirm('Manuelles Getränk löschen?'))return; state.manualDrinks=state.manualDrinks.filter(d=>d.id!==id); save(); }
function exportMaster(){ const t=activeTrip(); const payload={type:'aida-tracker-masterdata',schemaVersion:4,exportedAt:nowIso(),trip:{id:t.id,name:t.name,start:t.start,end:t.end,status:'active',people:t.people.map(p=>({id:p.id,name:p.name,packageId:p.packageId,packagePrice:Number(p.packagePrice||0),createdAt:p.createdAt||nowIso(),updatedAt:p.updatedAt||nowIso()}))},manualDrinks:state.manualDrinks||[],favoriteOverrides:state.favoriteOverrides||{},catalogSource:state.catalogSource||CATALOG_BASE_SOURCE,catalogOverrides:state.catalogOverrides||{},catalogAdditions:state.catalogAdditions||[]}; const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); downloadBlob(blob,`aida-stammdaten_${slug(t.name)}_${today()}.json`); }
function exportBackup(){ const t=activeTrip(); const payload={type:'aida-tracker-fullbackup',schemaVersion:4,exportId:uid('exp'),exportedAt:nowIso(),device:{id:state.device.id,name:state.device.name,recorderPersonId:state.device.recorderPersonId},activeTripId:state.activeTripId,trips:state.trips,manualDrinks:state.manualDrinks||[],favoriteOverrides:state.favoriteOverrides||{},catalogSource:state.catalogSource||CATALOG_BASE_SOURCE,catalogOverrides:state.catalogOverrides||{},catalogAdditions:state.catalogAdditions||[]}; const stamp=new Date().toISOString().slice(0,16).replace('T','_').replace(':',''); const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}); downloadBlob(blob,`aida-tracker_backup_${slug(t.name)}_${shortId(state.device.id)}_${stamp}.json`); }
function exportCsv(){ const {rows}=calcTrip(); const t=activeTrip(); const head=['Reise','DatumUhrzeit','KonsumiertVon','ErfasstVon','Paket','Getraenk','Kategorie','Groesse','Menge','Einzelpreis','Barkartenwert','Paketstatus','Geraet','Notiz']; const lines=[head.join(';')]; rows.slice().reverse().forEach(r=>{const e=r.entry, rec=personById(e.recordedByPersonId)||{name:''}; const arr=[t.name,new Date(e.at||e.createdAt).toLocaleString('de-DE'),r.person.name,rec.name,packageName(r.person.packageId),r.drink.name,r.drink.category,r.drink.size||'',String(r.qty).replace('.',','),String(r.unit.toFixed(2)).replace('.',','),String(r.value.toFixed(2)).replace('.',','),STATUS_LABEL[r.status],e.sourceDeviceId||'',e.note||'']; lines.push(arr.map(x=>'"'+String(x).replaceAll('"','""')+'"').join(';')); }); downloadBlob(new Blob(['\ufeff'+lines.join('\n')],{type:'text/csv;charset=utf-8'}),`aida-eintraege_${slug(t.name)}_${today()}.csv`); }
function importFile(ev){ const file=ev.target.files[0]; if(!file)return; const reader=new FileReader(); reader.onload=()=>{ try{ const data=JSON.parse(reader.result); const result=mergeImport(data); save(); toast(result); }catch(e){ console.error(e); alert('JSON konnte nicht importiert werden.'); } }; reader.readAsText(file); ev.target.value=''; }
function mergeImport(data){
  if(data.type==='aida-tracker-masterdata') return importMasterData(data);
  if(data.type==='aida-tracker-fullbackup') return importFullBackup(data);
  if(data.trips && data.drinks){ // legacy backup from previous HTML app
    return importLegacy(data);
  }
  throw new Error('Unbekanntes Format');
}
function mergePersonList(targetTrip, incomingPeople){ let added=0, updated=0; for(const p of incomingPeople||[]){ const ex=targetTrip.people.find(x=>x.id===p.id); if(ex){ Object.assign(ex,{name:p.name,packageId:p.packageId||'none',packagePrice:Number(p.packagePrice||0),updatedAt:p.updatedAt||nowIso()}); updated++; } else { targetTrip.people.push({id:p.id||uid('p'),name:p.name,packageId:p.packageId||'none',packagePrice:Number(p.packagePrice||0),createdAt:p.createdAt||nowIso(),updatedAt:p.updatedAt||nowIso()}); added++; } } return {added,updated}; }
function importMasterData(data){ const inc=data.trip; if(!inc) throw new Error('Keine Reise'); let t=state.trips.find(x=>x.id===inc.id); let created=false; if(!t){ t={id:inc.id||uid('trip'),name:inc.name||'Importierte Reise',start:inc.start||'',end:inc.end||'',status:'active',people:[],entries:[],createdAt:nowIso(),updatedAt:nowIso()}; state.trips.unshift(t); created=true; } else { t.name=inc.name||t.name; t.start=inc.start||t.start; t.end=inc.end||t.end; t.updatedAt=nowIso(); }
  const r=mergePersonList(t, inc.people||[]); mergeManualDrinks(data.manualDrinks||[]); mergeCatalogPayload(data); if(data.favoriteOverrides) state.favoriteOverrides=Object.assign(state.favoriteOverrides||{}, data.favoriteOverrides); applyFavoriteOverrides(); state.activeTripId=t.id; if(!state.activePersonId && t.people[0]) state.activePersonId=t.people[0].id; return `Stammdaten importiert: ${created?'1 Reise angelegt, ':'Reise aktualisiert, '}${r.added} Personen neu, ${r.updated} aktualisiert.`; }
function importFullBackup(data){ let tripsNew=0, personsNew=0, entriesNew=0, entriesUpdated=0, entriesKnown=0; mergeManualDrinks(data.manualDrinks||[]); mergeCatalogPayload(data); if(data.favoriteOverrides) state.favoriteOverrides=Object.assign(state.favoriteOverrides||{}, data.favoriteOverrides);
  for(const inc of data.trips||[]){ let t=state.trips.find(x=>x.id===inc.id); if(!t){ t={id:inc.id,name:inc.name,start:inc.start,end:inc.end,status:inc.status||'active',people:[],entries:[],createdAt:inc.createdAt||nowIso(),updatedAt:inc.updatedAt||nowIso()}; state.trips.push(t); tripsNew++; } else { t.name=inc.name||t.name; t.start=inc.start||t.start; t.end=inc.end||t.end; t.status=inc.status||t.status; }
    const r=mergePersonList(t, inc.people||[]); personsNew += r.added;
    const index=new Map(t.entries.map(e=>[e.id,e]));
    for(const e of inc.entries||[]){ if(!e.id) continue; const ex=index.get(e.id); if(!ex){ t.entries.push(e); entriesNew++; } else { const a=Date.parse(ex.updatedAt||ex.createdAt||0), b=Date.parse(e.updatedAt||e.createdAt||0); if(b>a){ Object.assign(ex,e); entriesUpdated++; } else entriesKnown++; } }
  }
  return `Vollbackup zusammengeführt: ${tripsNew} Reisen neu, ${personsNew} Personen neu, ${entriesNew} Einträge neu, ${entriesUpdated} aktualisiert, ${entriesKnown} bekannt.`; }
function importLegacy(data){ // Previous single-file format: preserve trips, people, entries. Drinks are ignored except manual additions cannot be detected reliably.
  let count=0; for(const inc of data.trips||[]){ let t=state.trips.find(x=>x.id===inc.id); if(!t){ state.trips.push({id:inc.id,name:inc.name,start:inc.start,end:inc.end,status:inc.closed?'closed':'active',people:inc.people||[],entries:inc.entries||[]}); count++; } }
  return `Altes Backup importiert: ${count} Reisen übernommen.`; }
function mergeManualDrinks(ds){ state.manualDrinks=state.manualDrinks||[]; for(const d of ds||[]){ if(!state.manualDrinks.some(x=>x.id===d.id)) state.manualDrinks.push(d); } }

function mergeCatalogPayload(data){
  if(!data) return;
  if(data.catalogSource) state.catalogSource = Object.assign({}, state.catalogSource||CATALOG_BASE_SOURCE, data.catalogSource);
  state.catalogOverrides = Object.assign(state.catalogOverrides||{}, data.catalogOverrides||{});
  mergeCatalogAdditions(data.catalogAdditions||[]);
}
function mergeCatalogAdditions(ds){ state.catalogAdditions=state.catalogAdditions||[]; for(const d of ds||[]){ if(!d || !d.name) continue; const ex=state.catalogAdditions.find(x=>x.id===d.id) || state.catalogAdditions.find(x=>drinkKey(x)===drinkKey(d)); if(ex) Object.assign(ex,d,{packages:Object.assign({},ex.packages||{},d.packages||{})}); else state.catalogAdditions.push(normalizeDrinkInput(d)); } }
function parseStatusValue(v){ const s=normalizeKeyPart(v); if(['ja','x','1','true','enthalten','included','inkl','inkludiert'].includes(s)) return 'included'; if(['nein','0','false','nicht enthalten','excluded','ausgeschlossen'].includes(s)) return 'excluded'; return 'unclear'; }
function packageObjFromSource(x){ const p=x.packages||{}; return { all_in: parseStatusValue(p.all_in ?? x.all_in ?? x['ALL IN'] ?? x['All In'] ?? x['Paket ALL IN']), fun: parseStatusValue(p.fun ?? x.fun ?? x['FUN'] ?? x['Paket FUN']), kids_all_in: parseStatusValue(p.kids_all_in ?? x.kids_all_in ?? x['Kids & Teens ALL IN'] ?? x['kids & teens all in'] ?? x['Paket Kids & Teens ALL IN']), kids_fun: parseStatusValue(p.kids_fun ?? x.kids_fun ?? x['Kids & Teens FUN'] ?? x['kids & teens fun'] ?? x['Paket Kids & Teens FUN']) }; }
function normalizeDrinkInput(x){
  const name = String(x.name ?? x.Name ?? x.Getraenk ?? x.Getränk ?? x.Artikel ?? '').trim();
  const category = String(x.category ?? x.Category ?? x.Kategorie ?? '').trim() || 'Sonstiges';
  const size = String(x.size ?? x.Size ?? x.Groesse ?? x.Größe ?? '').trim();
  const price = Number(x.price ?? x.Preis ?? parseMoney(x.priceText ?? x.PreisText ?? x.Barkartenpreis ?? '0')) || parseMoney(x.price ?? x.Preis ?? x.Barkartenpreis ?? 0);
  const id = String(x.id ?? x.ID ?? '').trim() || ('imp_' + slug(category+'_'+name+'_'+size));
  return { id, name, category, price, size, packages: packageObjFromSource(x), note:String(x.note ?? x.Notiz ?? '').trim(), favorite:!!x.favorite, source:String(x.source ?? x.Quelle ?? 'Kartenimport').trim(), updatedAt: nowIso() };
}
function parseCsv(text){
  const lines=String(text||'').split(/\r?\n/).filter(x=>x.trim()); if(!lines.length) return [];
  const sep=(lines[0].match(/;/g)||[]).length >= (lines[0].match(/,/g)||[]).length ? ';' : ',';
  const parseLine=line=>{ const out=[]; let cur='', q=false; for(let i=0;i<line.length;i++){ const ch=line[i]; if(ch==='"' && line[i+1]==='"'){cur+='"'; i++;} else if(ch==='"'){q=!q;} else if(ch===sep && !q){out.push(cur); cur='';} else cur+=ch; } out.push(cur); return out.map(x=>x.trim()); };
  const headers=parseLine(lines[0]);
  return lines.slice(1).map(line=>{ const cells=parseLine(line); const o={}; headers.forEach((h,i)=>o[h]=cells[i]??''); return o; });
}
function parseCatalogUpload(text, fileName){
  if(/\.pdf$/i.test(fileName||'')) throw new Error('PDF-Dateien können in der App offline nicht zuverlässig automatisch ausgelesen werden. Bitte die PDF zuerst in ChatGPT auswerten lassen und den erzeugten Katalog als JSON/CSV importieren.');
  if(/\.csv$/i.test(fileName||'')){ const rows=parseCsv(text).map(normalizeDrinkInput).filter(d=>d.name&&d.price); return {meta:{name:fileName,version:'CSV-Import',loadedAt:today()},drinks:rows}; }
  const data=JSON.parse(text);
  const raw = Array.isArray(data) ? data : (data.drinks || data.catalog || data.items || []);
  if(!Array.isArray(raw)) throw new Error('Kein Getränke-Array gefunden. Erwartet wird JSON mit drinks:[...] oder eine CSV-Datei.');
  const meta = data.catalogSource || data.meta || {name:fileName||'Katalogimport',version:data.version||'',loadedAt:today()};
  return {meta, drinks:raw.map(normalizeDrinkInput).filter(d=>d.name&&d.price)};
}
function compareCatalog(newDrinks, meta){
  const current=currentCatalog(true);
  const byId=new Map(current.map(d=>[d.id,d])); const byKey=new Map(current.map(d=>[drinkKey(d),d])); const byNameSize=new Map(current.map(d=>[drinkNameSizeKey(d),d]));
  const seen=new Set(); const diff={meta:meta||{}, importedAt:nowIso(), total:newDrinks.length, unchanged:[], changed:[], added:[], missing:[]};
  for(const nd of newDrinks){
    let old=byId.get(nd.id) || byKey.get(drinkKey(nd)) || byNameSize.get(drinkNameSizeKey(nd));
    if(old){ seen.add(old.id); const changes=[]; if(Math.abs(Number(old.price||0)-Number(nd.price||0))>0.001) changes.push({field:'price',old:old.price,new:nd.price}); if(normalizeKeyPart(old.category)!==normalizeKeyPart(nd.category)) changes.push({field:'category',old:old.category,new:nd.category}); for(const k of ['all_in','fun','kids_all_in','kids_fun']){ if((old.packages?.[k]||'unclear') !== (nd.packages?.[k]||'unclear')) changes.push({field:k,old:old.packages?.[k]||'unclear',new:nd.packages?.[k]||'unclear'}); } if(changes.length) diff.changed.push({oldId:old.id, old, incoming:nd, changes}); else diff.unchanged.push({oldId:old.id, incoming:nd}); }
    else diff.added.push({incoming:nd});
  }
  for(const d of current){ if(!seen.has(d.id) && d.source!=='manuell') diff.missing.push({oldId:d.id, old:d}); }
  return diff;
}
function handleCatalogImport(ev){ const file=ev.target.files[0]; if(!file)return; const reader=new FileReader(); reader.onload=()=>{ try{ const parsed=parseCatalogUpload(reader.result, file.name); pendingCatalogImport={meta:parsed.meta,drinks:parsed.drinks,diff:compareCatalog(parsed.drinks, parsed.meta)}; state.lastCatalogDiff=pendingCatalogImport.diff; save(); toast('Katalog verglichen. Bitte Ergebnis prüfen und bei Bedarf übernehmen.'); showPage('catalog'); }catch(e){ console.error(e); alert(e.message || 'Katalog konnte nicht importiert werden.'); } }; reader.readAsText(file); ev.target.value=''; }
function renderCatalogDiff(){
  const box=$('catalogDiff'); if(!box) return; const diff=pendingCatalogImport?.diff || state.lastCatalogDiff;
  if(!diff){ box.innerHTML='<p class="tiny muted">Noch kein neuer Katalog verglichen. Import möglich als JSON/CSV. PDF bitte zuerst außerhalb der App strukturiert auswerten lassen.</p>'; return; }
  const sample=(arr,fn)=>arr.slice(0,8).map(fn).join('') || '<li>keine</li>';
  box.innerHTML=`<div class="kpis"><div class="kpi"><span class="label">Importpositionen</span><span class="value">${diff.total||0}</span></div><div class="kpi"><span class="label">unverändert</span><span class="value">${diff.unchanged.length}</span></div><div class="kpi"><span class="label">geändert</span><span class="value">${diff.changed.length}</span></div><div class="kpi"><span class="label">neu</span><span class="value">${diff.added.length}</span></div></div><p class="tiny muted">Nicht mehr in neuer Karte gefunden: <b>${diff.missing.length}</b>. Diese Positionen werden beim Übernehmen nicht gelöscht, sondern als „nicht in aktueller Karte“ markiert, damit alte Einträge auswertbar bleiben.</p><details><summary>Preis-/Paketänderungen anzeigen</summary><ul>${sample(diff.changed,x=>`<li><b>${escapeHtml(x.old.name)}</b>: ${escapeHtml(x.changes.map(c=>c.field==='price'?'Preis '+eur(c.old)+' → '+eur(c.new):(c.field==='category'?'Kategorie '+c.old+' → '+c.new:c.field+' '+(STATUS_LABEL[c.old]||c.old)+' → '+(STATUS_LABEL[c.new]||c.new))).join(', '))}</li>`)}</ul></details><details><summary>Neue Artikel anzeigen</summary><ul>${sample(diff.added,x=>`<li><b>${escapeHtml(x.incoming.name)}</b> · ${escapeHtml(x.incoming.category)} · ${eur(x.incoming.price)}</li>`)}</ul></details><div class="buttonRow"><button id="btnApplyCatalogImport" class="primary">Vergleich übernehmen</button><button id="btnClearCatalogDiff">Vergleich verwerfen</button></div>`;
  $('btnApplyCatalogImport').addEventListener('click', applyCatalogImport);
  $('btnClearCatalogDiff').addEventListener('click',()=>{pendingCatalogImport=null; state.lastCatalogDiff=null; save();});
}
function applyCatalogImport(){
  if(!pendingCatalogImport){ toast('Kein neuer Katalog zum Übernehmen vorhanden.'); return; }
  const diff=pendingCatalogImport.diff; state.catalogOverrides=state.catalogOverrides||{}; state.catalogAdditions=state.catalogAdditions||[];
  for(const c of diff.changed){ const nd=c.incoming; state.catalogOverrides[c.oldId]=Object.assign({}, state.catalogOverrides[c.oldId]||{}, {name:nd.name,category:nd.category,size:nd.size,price:nd.price,packages:nd.packages,note:nd.note,source:pendingCatalogImport.meta?.name||'Kartenimport',archived:false,updatedAt:nowIso()}); }
  for(const a of diff.added){ let nd=normalizeDrinkInput(a.incoming); if(currentCatalog(true).some(d=>d.id===nd.id)) nd.id=uid('imp'); nd.source=pendingCatalogImport.meta?.name||'Kartenimport'; nd.createdAt=nowIso(); state.catalogAdditions.push(nd); }
  for(const m of diff.missing){ state.catalogOverrides[m.oldId]=Object.assign({}, state.catalogOverrides[m.oldId]||{}, {archived:true, updatedAt:nowIso()}); }
  state.catalogSource=Object.assign({}, pendingCatalogImport.meta||{}, {loadedAt:today(), importedAt:nowIso()}); pendingCatalogImport=null; state.lastCatalogDiff=diff; save(); toast(`Katalog übernommen: ${diff.changed.length} geändert, ${diff.added.length} neu, ${diff.missing.length} markiert.`);
}
function exportCatalogData(){ const payload={type:'aida-drink-catalog',schemaVersion:4,catalogSource:state.catalogSource||CATALOG_BASE_SOURCE,exportedAt:nowIso(),drinks:currentCatalog(false).map(d=>({id:d.id,name:d.name,category:d.category,price:d.price,size:d.size||'',packages:d.packages,note:d.note||'',source:d.source||''}))}; downloadBlob(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}),`aida-katalog_${slug(payload.catalogSource.name||'katalog')}_${today()}.json`); }
function renderOnboardingIfNeeded(){
  const t=activeTrip(); const needs=!state.device.setupDone || !state.device.name || !state.device.recorderPersonId || !personById(state.device.recorderPersonId,t);
  const box=$('onboarding'); if(!needs){ box.classList.add('hidden'); box.innerHTML=''; return; }
  const hasPeople=t.people.length>0;
  box.classList.remove('hidden');
  box.innerHTML = `<div class="modalCard"><h2>Ersteinrichtung</h2><p class="muted">Diese Angaben werden nur lokal auf diesem Gerät gespeichert. Personen und Paketpreise kannst du als Stammdaten separat exportieren.</p><label class="lbl">Gerätename</label><input id="obDeviceName" class="input" placeholder="z. B. Fabian iPhone" value="${escapeHtml(state.device.name||'')}">${hasPeople?`<label class="lbl">Wer nutzt dieses Gerät?</label><select id="obRecorder" class="input">${t.people.map(p=>`<option value="${p.id}" ${state.device.recorderPersonId===p.id?'selected':''}>${escapeHtml(p.name)}</option>`).join('')}</select><button id="obSave" class="primary full">Gerät einrichten</button>`:`<label class="lbl">Reisename</label><input id="obTripName" class="input" placeholder="z. B. AIDA August 2026" value="${escapeHtml(t.name||'')}"><label class="lbl">Dein Name</label><input id="obPersonName" class="input" placeholder="Name"><label class="lbl">Dein Getränkepaket</label><select id="obPackage" class="input">${packageOptions('none')}</select><label class="lbl">Paketpreis für dich / diese Reise</label><input id="obPackagePrice" class="input" inputmode="decimal" placeholder="z. B. 259,00"><button id="obSave" class="primary full">Erste Person und Gerät einrichten</button>`}<div class="stack" style="margin-top:12px"><label class="fileBtn" for="obImportFile">Stammdaten importieren</label><input id="obImportFile" type="file" accept="application/json" class="hidden"></div></div>`;
  $('obImportFile').addEventListener('change', importFile);
  $('obSave').addEventListener('click',()=>{
    state.device.name = $('obDeviceName').value.trim() || 'iPhone';
    if(hasPeople){ state.device.recorderPersonId = $('obRecorder').value; if(!state.activePersonId) state.activePersonId = $('obRecorder').value; }
    else { t.name=$('obTripName').value.trim()||'Reise'; const name=$('obPersonName').value.trim(); if(!name){toast('Name fehlt.'); return;} const p={id:uid('p'),name,packageId:$('obPackage').value||'none',packagePrice:parseMoney($('obPackagePrice').value),createdAt:nowIso(),updatedAt:nowIso()}; t.people.push(p); state.device.recorderPersonId=p.id; state.activePersonId=p.id; }
    state.device.setupDone=true; save(); toast('Einrichtung gespeichert.');
  });
}
function showInstallHint(){
  const hint=$('installHint');
  const standalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone;
  if(standalone){ hint.classList.add('hidden'); return; }
  hint.innerHTML = 'Für schnellen Zugriff: In Safari öffnen → Teilen → <b>Zum Home-Bildschirm hinzufügen</b>. Danach startet die App über das Icon und arbeitet offline, sobald sie einmal vollständig geladen wurde.';
  hint.classList.remove('hidden');
}
function bind(){
  document.addEventListener('click', e=>{ const g=e.target.closest('[data-goto]'); if(g) showPage(g.dataset.goto); });
  $('drinkSearch').addEventListener('input', renderCapture); $('entrySearch').addEventListener('input', renderEntries); $('catalogSearch').addEventListener('input', renderCatalog);
  $('btnUndo').addEventListener('click', undoLast); $('btnCsv').addEventListener('click', exportCsv); $('btnQuickBackup').addEventListener('click', exportBackup);
  $('btnSaveDevice').addEventListener('click', saveDevice); $('btnSaveTrip').addEventListener('click', saveTrip); $('tripSelect').addEventListener('change', switchTrip); $('btnNewTrip').addEventListener('click', newTrip); $('btnCloseTrip').addEventListener('click', closeTrip); $('btnAddPerson').addEventListener('click', addPerson);
  $('btnExportMaster').addEventListener('click', exportMaster); $('btnExportBackup').addEventListener('click', exportBackup); $('importFile').addEventListener('change', importFile);
  $('btnAddDrink').addEventListener('click', addManualDrink);
  $('catalogImportFile').addEventListener('change', handleCatalogImport);
  $('btnExportCatalog').addEventListener('click', exportCatalogData);
}
function registerSw(){ if('serviceWorker' in navigator){ navigator.serviceWorker.register('./sw.js').catch(err=>console.warn('SW failed',err)); } }

load(); applyFavoriteOverrides(); bind(); showInstallHint(); registerSw(); render();
})();
