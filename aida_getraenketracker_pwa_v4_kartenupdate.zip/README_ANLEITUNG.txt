AIDA Getränketracker PWA
=========================

Inhalt
------
- index.html
- style.css
- app.js
- catalog.js
- manifest.webmanifest
- sw.js
- icons/icon-192.png
- icons/icon-512.png

Wichtig
-------
Dieses PWA-Paket enthält keine Personen, keine Paketpreise und keine Konsumeinträge.
Persönliche Stammdaten bleiben lokal auf dem jeweiligen iPhone.

Installation auf dem iPhone
---------------------------
1. Dateien auf eine statische HTTPS-Ablage hochladen, z. B. GitHub Pages, Netlify oder einen eigenen Webspace.
2. index.html in Safari auf dem iPhone öffnen.
3. Teilen -> Zum Home-Bildschirm hinzufügen.
4. App einmal starten und Ersteinrichtung durchführen.
5. Flugmodus testen.

Empfohlener Datenablauf für zwei iPhones
----------------------------------------
1. Auf dem Hauptgerät Reise und alle Personen zentral anlegen.
2. Paket je Person per Dropdown wählen.
3. Paketpreis je Person eingeben.
4. Stammdaten aktuelle Reise exportieren.
5. JSON-Datei an das zweite iPhone übertragen, z. B. per iCloud Drive oder AirDrop.
6. Auf dem zweiten iPhone in der App JSON importieren.
7. Dort nur noch Gerät einrichten und Standard-Erfasser auswählen.

Exporte
-------
- Stammdatenexport: Reise, Personen, Paketzuordnung und Paketpreise. Ohne Geräte-ID, ohne Einträge.
- Vollbackup: inklusive Einträge und Geräteinformationen. Dateiname enthält die Geräte-ID.
- CSV: Einträge der aktiven Reise für Excel/Numbers.

Offline
-------
Die PWA cached die App-Dateien per Service Worker. Nach der Installation und dem ersten vollständigen Laden sollte die App offline starten. Vor der Reise im Flugmodus testen.


UPDATE BARKARTE / GETRAENKEPAKETE
----------------------------------
Der eingebaute Stammkatalog basiert auf der hochgeladenen AIDA-Barkarte, Stand 01.11.2025, und wurde am 09.07.2026 in die App übernommen.

Unter "Katalog" gibt es den Bereich "Barkarte / Paketlogik aktualisieren".
Dort kannst du:
1. den aktuellen Katalog als JSON exportieren,
2. einen neuen strukturierten Katalog als JSON oder CSV importieren,
3. automatisch vergleichen lassen:
   - unveränderte Artikel,
   - Preisänderungen,
   - geänderte Paketzuordnung je Paket,
   - neue Artikel,
   - nicht mehr gefundene Artikel.

Wichtig: Eine PDF kann die PWA offline nicht zuverlässig selbst auslesen. Vorgehen bei neuer PDF:
1. Neue Barkarte in ChatGPT auswerten lassen.
2. Daraus einen strukturierten Katalog als JSON oder CSV erzeugen lassen.
3. Diese Datei in der App unter "Neuen Katalog vergleichen" importieren.
4. Vergleich prüfen und übernehmen.

Beim Übernehmen werden alte Einträge nicht beschädigt. Getränke, die in der neuen Karte fehlen, werden nicht gelöscht, sondern als "nicht in aktueller Karte" markiert. Dadurch bleiben frühere Reisen und Auswertungen nachvollziehbar.

Der Stammdatenexport enthält nun auch lokale Katalogaktualisierungen. Wenn du die Stammdaten an deine Frau gibst, erhält sie damit dieselbe Reise, dieselben Personen, dieselben Pakete/Paketpreise und denselben aktualisierten Katalog - weiterhin ohne Geräte-ID und ohne Konsumeinträge.
