const AIDA_DRINKS = [
  {
    "id": "d001",
    "name": "Coconut Mai Tai",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d002",
    "name": "Coconut Mai Tai alkoholfrei",
    "category": "Cocktails",
    "price": 8.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d003",
    "name": "White Basil",
    "category": "Cocktails",
    "price": 8.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d004",
    "name": "AIDA Icebreaker",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d005",
    "name": "AIDA Honey Mule",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d006",
    "name": "AIDA Honey Mule alkoholfrei",
    "category": "Cocktails",
    "price": 8.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d007",
    "name": "Deep Purple Magic Sour",
    "category": "Cocktails",
    "price": 11.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d008",
    "name": "Dark & Stormy",
    "category": "Cocktails",
    "price": 9.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d009",
    "name": "Mojito",
    "category": "Cocktails",
    "price": 9.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d010",
    "name": "Mojito alkoholfrei",
    "category": "Cocktails",
    "price": 8.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d011",
    "name": "Sex on the Beach",
    "category": "Cocktails",
    "price": 9.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d012",
    "name": "AIDA Mai Tai",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d013",
    "name": "Caipirinha",
    "category": "Cocktails",
    "price": 9.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d014",
    "name": "Caipirinha alkoholfrei",
    "category": "Cocktails",
    "price": 8.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d015",
    "name": "Piña Colada",
    "category": "Cocktails",
    "price": 9.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d016",
    "name": "Original Pat O'Brien's Hurricane",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d017",
    "name": "Swimming Pool",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d018",
    "name": "Long Island Iced Tea",
    "category": "Cocktails",
    "price": 11.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d019",
    "name": "Margarita",
    "category": "Cocktails",
    "price": 8.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d020",
    "name": "Margarita alkoholfrei",
    "category": "Cocktails",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d021",
    "name": "Whiskey Sour",
    "category": "Cocktails",
    "price": 8.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d022",
    "name": "Whiskey Sour alkoholfrei",
    "category": "Cocktails",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d023",
    "name": "Cosmopolitan",
    "category": "Cocktails",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d024",
    "name": "Espresso Martini",
    "category": "Cocktails",
    "price": 8.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d025",
    "name": "Negroni",
    "category": "Cocktails",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d026",
    "name": "Erdbeer Colada",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 7.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d027",
    "name": "Ipanema",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 7.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d028",
    "name": "Banana Split",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 6.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d029",
    "name": "Coco Choco Loco",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d030",
    "name": "Apple Crumble",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d031",
    "name": "Sunrise",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 6.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d032",
    "name": "Aquarium",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 7.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d033",
    "name": "Palm Beach",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 6.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d034",
    "name": "Cherry Bomb",
    "category": "Juicy Cocktails alkoholfrei",
    "price": 7.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d035",
    "name": "Gin Tonic",
    "category": "Longdrinks & Gin Tonics",
    "price": 10.6,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d036",
    "name": "Vodka Red Bull",
    "category": "Longdrinks & Gin Tonics",
    "price": 9.6,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d037",
    "name": "Vodka Cranberry",
    "category": "Longdrinks & Gin Tonics",
    "price": 8.3,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d038",
    "name": "Whiskey Cola",
    "category": "Longdrinks & Gin Tonics",
    "price": 9.3,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d039",
    "name": "Campari Soda",
    "category": "Longdrinks & Gin Tonics",
    "price": 8.3,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d040",
    "name": "Campari Orange",
    "category": "Longdrinks & Gin Tonics",
    "price": 8.3,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d041",
    "name": "Rum Cola",
    "category": "Longdrinks & Gin Tonics",
    "price": 8.3,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d042",
    "name": "Cuba Libre",
    "category": "Longdrinks & Gin Tonics",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d043",
    "name": "Cuba Libre alkoholfrei",
    "category": "Longdrinks & Gin Tonics",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d044",
    "name": "Deep & Purple G&T",
    "category": "Longdrinks & Gin Tonics",
    "price": 11.6,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d045",
    "name": "AIDA Guilty Pleasure",
    "category": "Longdrinks & Gin Tonics",
    "price": 11.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d046",
    "name": "Garden & Tonic",
    "category": "Longdrinks & Gin Tonics",
    "price": 10.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d047",
    "name": "Italian G&T",
    "category": "Longdrinks & Gin Tonics",
    "price": 12.0,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d048",
    "name": "Little Berry alkoholfrei",
    "category": "Sprizz & Shots",
    "price": 8.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Alkoholfreie Sprizz-Variante",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d049",
    "name": "Lillet Berry",
    "category": "Sprizz & Shots",
    "price": 9.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d050",
    "name": "Aperitivo Sprizz alkoholfrei",
    "category": "Sprizz & Shots",
    "price": 8.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Alkoholfreie Sprizz-Variante",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d051",
    "name": "Aperol Sprizz",
    "category": "Sprizz & Shots",
    "price": 9.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d052",
    "name": "AIDA Sprizz alkoholfrei",
    "category": "Sprizz & Shots",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Alkoholfreie Sprizz-Variante",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d053",
    "name": "AIDA Sprizz",
    "category": "Sprizz & Shots",
    "price": 8.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d054",
    "name": "Hugo alkoholfrei",
    "category": "Sprizz & Shots",
    "price": 7.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Alkoholfreie Sprizz-Variante",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d055",
    "name": "Hugo",
    "category": "Sprizz & Shots",
    "price": 8.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d056",
    "name": "AIDA Hot Lips Shot",
    "category": "Sprizz & Shots",
    "price": 4.9,
    "size": "",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Shot; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d057",
    "name": "B-52 Shot",
    "category": "Sprizz & Shots",
    "price": 4.9,
    "size": "",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Shot; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d058",
    "name": "Hellfire Shot",
    "category": "Sprizz & Shots",
    "price": 4.9,
    "size": "",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Shot; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d059",
    "name": "Radeberger Pilsner vom Fass",
    "category": "Biere",
    "price": 5.5,
    "size": "0,5 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d060",
    "name": "Radeberger Pilsner vom Fass",
    "category": "Biere",
    "price": 4.0,
    "size": "0,3 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d061",
    "name": "Schöfferhofer Weizen 0,0 %",
    "category": "Biere",
    "price": 5.5,
    "size": "0,5 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d062",
    "name": "Jever Fun alkoholfrei",
    "category": "Biere",
    "price": 4.6,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d063",
    "name": "Schöfferhofer Grapefruit alkoholfrei",
    "category": "Biere",
    "price": 4.6,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d064",
    "name": "Schöfferhofer Hefeweizen",
    "category": "Biere",
    "price": 5.5,
    "size": "0,5 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d065",
    "name": "Radeberger Pilsner Flasche",
    "category": "Biere",
    "price": 4.0,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d066",
    "name": "Corona",
    "category": "Biere",
    "price": 4.8,
    "size": "0,355 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d067",
    "name": "Salitos",
    "category": "Biere",
    "price": 4.6,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d068",
    "name": "Heineken",
    "category": "Biere",
    "price": 4.6,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d069",
    "name": "Schöfferhofer Grapefruit",
    "category": "Biere",
    "price": 4.6,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d070",
    "name": "Brogsitter Edition AIDA Weiß Cuvée Glas",
    "category": "Weine",
    "price": 8.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d071",
    "name": "Brogsitter Edition AIDA Weiß Cuvée Flasche",
    "category": "Weine",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d072",
    "name": "Pinot Grigio Glas",
    "category": "Weine",
    "price": 8.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d073",
    "name": "Pinot Grigio Flasche",
    "category": "Weine",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d074",
    "name": "Bio-Riesling Glas",
    "category": "Weine",
    "price": 8.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d075",
    "name": "Bio-Riesling Flasche",
    "category": "Weine",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d076",
    "name": "Brogsitter Edition AIDA Rot Cuvée Glas",
    "category": "Weine",
    "price": 8.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d077",
    "name": "Brogsitter Edition AIDA Rot Cuvée Flasche",
    "category": "Weine",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d078",
    "name": "Primitivo Glas",
    "category": "Weine",
    "price": 10.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d079",
    "name": "Primitivo Flasche",
    "category": "Weine",
    "price": 34.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d080",
    "name": "Cabernet Sauvignon Glas",
    "category": "Weine",
    "price": 10.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d081",
    "name": "Cabernet Sauvignon Flasche",
    "category": "Weine",
    "price": 34.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d082",
    "name": "Brogsitter Edition AIDA Pinot Noir Rosé Glas",
    "category": "Weine",
    "price": 8.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d083",
    "name": "Brogsitter Edition AIDA Pinot Noir Rosé Flasche",
    "category": "Weine",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d084",
    "name": "Bardolino Chiaretto Glas",
    "category": "Weine",
    "price": 8.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Wein im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d085",
    "name": "Bardolino Chiaretto Flasche",
    "category": "Weine",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d086",
    "name": "Brogsitter B•ICED Demi Sec Glas",
    "category": "Prickelndes",
    "price": 5.9,
    "size": "0,1 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Sekt/Prosecco im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d087",
    "name": "Brogsitter B•ICED Demi Sec Flasche",
    "category": "Prickelndes",
    "price": 34.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d088",
    "name": "Brogsitter B•ICED Rosé Demi Sec Glas",
    "category": "Prickelndes",
    "price": 5.9,
    "size": "0,1 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Sekt/Prosecco im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d089",
    "name": "Brogsitter B•ICED Rosé Demi Sec Flasche",
    "category": "Prickelndes",
    "price": 34.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d090",
    "name": "Brogsitter Prestige Edition AIDA Brut Glas",
    "category": "Prickelndes",
    "price": 4.9,
    "size": "0,1 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Sekt/Prosecco im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d091",
    "name": "Brogsitter Prestige Edition AIDA Brut Flasche",
    "category": "Prickelndes",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d092",
    "name": "Brogsitter Prestige Edition AIDA Rosé trocken Glas",
    "category": "Prickelndes",
    "price": 4.9,
    "size": "0,1 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Sekt/Prosecco im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d093",
    "name": "Brogsitter Prestige Edition AIDA Rosé trocken Flasche",
    "category": "Prickelndes",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d094",
    "name": "Prosecco Extra Dry Glas",
    "category": "Prickelndes",
    "price": 4.9,
    "size": "0,1 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Sekt/Prosecco im Glas",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d095",
    "name": "Prosecco Extra Dry Flasche",
    "category": "Prickelndes",
    "price": 27.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Flaschenware laut Barkarte/Paketfußnote ausgenommen",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d096",
    "name": "Sekt/Prosecco auf Eis",
    "category": "Prickelndes",
    "price": 6.6,
    "size": "0,15 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d097",
    "name": "Jacquart Millésimé Cuvée Alpha Flasche",
    "category": "Champagner",
    "price": 149.0,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Champagner/Flaschenware nicht als Paketleistung erkennbar",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d098",
    "name": "Jacquart Rosé Brut Flasche",
    "category": "Champagner",
    "price": 89.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Champagner/Flaschenware nicht als Paketleistung erkennbar",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d099",
    "name": "Jacquart Rosé Brut Glas",
    "category": "Champagner",
    "price": 12.6,
    "size": "0,1 l",
    "packages": {
      "all_in": "unclear",
      "fun": "unclear",
      "kids_all_in": "unclear",
      "kids_fun": "unclear"
    },
    "note": "Champagner im Glas: in der Pakettabelle nicht eindeutig genannt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d100",
    "name": "JM. Gobillard & Fils Rosé Brut Flasche",
    "category": "Champagner",
    "price": 64.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Champagner/Flaschenware nicht als Paketleistung erkennbar",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d101",
    "name": "JM. Gobillard & Fils Rosé Brut Glas",
    "category": "Champagner",
    "price": 9.6,
    "size": "0,1 l",
    "packages": {
      "all_in": "unclear",
      "fun": "unclear",
      "kids_all_in": "unclear",
      "kids_fun": "unclear"
    },
    "note": "Champagner im Glas: in der Pakettabelle nicht eindeutig genannt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d102",
    "name": "JM. Gobillard & Fils Tradition Brut Flasche",
    "category": "Champagner",
    "price": 59.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Champagner/Flaschenware nicht als Paketleistung erkennbar",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d103",
    "name": "JM. Gobillard & Fils Tradition Brut Glas",
    "category": "Champagner",
    "price": 9.6,
    "size": "0,1 l",
    "packages": {
      "all_in": "unclear",
      "fun": "unclear",
      "kids_all_in": "unclear",
      "kids_fun": "unclear"
    },
    "note": "Champagner im Glas: in der Pakettabelle nicht eindeutig genannt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d104",
    "name": "AIDA Deep & Purple Gin",
    "category": "Spirituosen - Gin",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d105",
    "name": "Monkey 47 Schwarzwald Dry Gin",
    "category": "Spirituosen - Gin",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d106",
    "name": "AIDA Gin",
    "category": "Spirituosen - Gin",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d107",
    "name": "UNDONE No. 2 London Dry Juniper alkoholfrei",
    "category": "Spirituosen - Gin",
    "price": 5.5,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d108",
    "name": "Bombay Sapphire Gin",
    "category": "Spirituosen - Gin",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d109",
    "name": "Hendrick's Gin",
    "category": "Spirituosen - Gin",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d110",
    "name": "The Botanist Islay Gin",
    "category": "Spirituosen - Gin",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d111",
    "name": "AIDA Vodka",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d112",
    "name": "Grey Goose Altius",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 9.5,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d113",
    "name": "Grey Goose",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d114",
    "name": "Absolut Vodka",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d115",
    "name": "Patrón Reposado",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d116",
    "name": "Patrón Silver",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d117",
    "name": "Olmeca Silver",
    "category": "Spirituosen - Vodka & Tequila",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d118",
    "name": "Martell VSOP",
    "category": "Spirituosen - Brandy & Cognac",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d119",
    "name": "Martell VS",
    "category": "Spirituosen - Brandy & Cognac",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d120",
    "name": "Cardenal Mendoza",
    "category": "Spirituosen - Brandy & Cognac",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d121",
    "name": "Osborne Veterano",
    "category": "Spirituosen - Brandy & Cognac",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d122",
    "name": "Don Papa Baroko",
    "category": "Spirituosen - Rum",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d123",
    "name": "Mount Gay Eclipse",
    "category": "Spirituosen - Rum",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d124",
    "name": "Bacardí Superior",
    "category": "Spirituosen - Rum",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d125",
    "name": "Bacardí Ron 8 Años",
    "category": "Spirituosen - Rum",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d126",
    "name": "Bacardí Gold",
    "category": "Spirituosen - Rum",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d127",
    "name": "Ron Santa Teresa 1796",
    "category": "Spirituosen - Rum",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d128",
    "name": "UNDONE No. 1 Jamaican Dark Cane alkoholfrei",
    "category": "Spirituosen - Rum",
    "price": 5.5,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d129",
    "name": "Buffalo Trace",
    "category": "Spirituosen - Whisky",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d130",
    "name": "Maker's Mark",
    "category": "Spirituosen - Whisky",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d131",
    "name": "Jack Daniel's",
    "category": "Spirituosen - Whisky",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d132",
    "name": "Jameson",
    "category": "Spirituosen - Whisky",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d133",
    "name": "Chivas Regal 12 Years",
    "category": "Spirituosen - Whisky",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d134",
    "name": "Aberfeldy 12 Years",
    "category": "Spirituosen - Whisky",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d135",
    "name": "The Glenlivet Master's Distiller's Reserve",
    "category": "Spirituosen - Whisky",
    "price": 7.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d136",
    "name": "UNDONE No. 3 American Blend alkoholfrei",
    "category": "Spirituosen - Whisky",
    "price": 5.5,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d137",
    "name": "Campari",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d138",
    "name": "Noilly Prat Original Dry",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 5.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d139",
    "name": "Martini Bianco",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d140",
    "name": "Martini Rosso",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d141",
    "name": "Aperol",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d142",
    "name": "Lillet Blanc",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d143",
    "name": "Tio Pepe Palomino Fino",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d144",
    "name": "Sandeman Medium Dry",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d145",
    "name": "Sandeman Medium Sweet",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d146",
    "name": "Graham's Late Bottled Vintage Port",
    "category": "Spirituosen - Aperitif, Sherry & Port",
    "price": 5.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d147",
    "name": "Sambuca Molinari",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d148",
    "name": "Ouzo 12",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d149",
    "name": "Jägermeister",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d150",
    "name": "Ramazzotti",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d151",
    "name": "Averna",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d152",
    "name": "Fernet-Branca",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d153",
    "name": "Helbing Kümmel",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d154",
    "name": "Linie Aquavit",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d155",
    "name": "Jubilaeums Akvavit",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d156",
    "name": "Malteser Aquavit",
    "category": "Spirituosen - Bitter, Anis & Aquavit",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d157",
    "name": "Baileys",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d158",
    "name": "Nonino Il Prosecco Grappa",
    "category": "Spirituosen - Likör & Grappa",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d159",
    "name": "Nonino Lo Chardonnay Grappa",
    "category": "Spirituosen - Likör & Grappa",
    "price": 6.7,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d160",
    "name": "Malibu",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d161",
    "name": "Herzog Pistazienlikör",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d162",
    "name": "Dom Bénédictine",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d163",
    "name": "Ramazzotti Limoncello",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d164",
    "name": "Mozart White Chocolate",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d165",
    "name": "Mozart Black",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d166",
    "name": "St. Germain Holunderblütenlikör",
    "category": "Spirituosen - Likör & Grappa",
    "price": 4.9,
    "size": "4 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose/Likör; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d167",
    "name": "Williams Birne Obstbrand",
    "category": "Spirituosen - Obstbrand/Obstgeist",
    "price": 4.9,
    "size": "2 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d168",
    "name": "Alter Apfel Obstbrand",
    "category": "Spirituosen - Obstbrand/Obstgeist",
    "price": 4.9,
    "size": "2 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d169",
    "name": "Alte Kirsche Obstbrand",
    "category": "Spirituosen - Obstbrand/Obstgeist",
    "price": 4.9,
    "size": "2 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d170",
    "name": "Alte Zwetschge Obstbrand",
    "category": "Spirituosen - Obstbrand/Obstgeist",
    "price": 4.9,
    "size": "2 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d171",
    "name": "Waldhimbeergeist",
    "category": "Spirituosen - Obstbrand/Obstgeist",
    "price": 4.9,
    "size": "2 cl",
    "packages": {
      "all_in": "excluded",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Pur ausgeschenkte Spirituose; nicht als Paketkategorie aufgeführt",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d172",
    "name": "Coca-Cola",
    "category": "Alkoholfreie Getränke - Softdrinks",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d173",
    "name": "Coca-Cola Zero",
    "category": "Alkoholfreie Getränke - Softdrinks",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d174",
    "name": "Fanta",
    "category": "Alkoholfreie Getränke - Softdrinks",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d175",
    "name": "Sprite",
    "category": "Alkoholfreie Getränke - Softdrinks",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d176",
    "name": "Mineralwasser 0,75 l",
    "category": "Alkoholfreie Getränke - Wasser",
    "price": 6.9,
    "size": "0,75 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d177",
    "name": "Mineralwasser 0,25 l",
    "category": "Alkoholfreie Getränke - Wasser",
    "price": 2.6,
    "size": "0,25 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d178",
    "name": "Sodawasser",
    "category": "Alkoholfreie Getränke - Wasser",
    "price": 2.0,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d179",
    "name": "Ananassaft",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d180",
    "name": "Apfelsaft",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d181",
    "name": "Bananennektar",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d182",
    "name": "Cranberrysaft",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d183",
    "name": "Kirschnektar",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d184",
    "name": "Mangonektar",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d185",
    "name": "Maracujanektar",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d186",
    "name": "Orangensaft",
    "category": "Alkoholfreie Getränke - Säfte/Nektare",
    "price": 2.6,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d187",
    "name": "AIDA Lemonade",
    "category": "Alkoholfreie Getränke - Softdrinks",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d188",
    "name": "AIDA Iced Tea",
    "category": "Alkoholfreie Getränke - Softdrinks",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d189",
    "name": "Red Bull Energydrink",
    "category": "Premium-Softdrinks",
    "price": 3.9,
    "size": "0,25 l Dose",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Als zusätzlicher Premium-Softdrink eingestuft",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d190",
    "name": "Red Bull Energydrink zuckerfrei",
    "category": "Premium-Softdrinks",
    "price": 3.9,
    "size": "0,25 l Dose",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "Als zusätzlicher Premium-Softdrink eingestuft",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d191",
    "name": "Premium Indian Tonic Water",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d192",
    "name": "Mediterranean Tonic Water",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d193",
    "name": "Premium Wild Berry",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d194",
    "name": "Mexican Lime Soda",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d195",
    "name": "Raspberry & Orange Blossom Soda",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d196",
    "name": "Premium Ginger Ale",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d197",
    "name": "Premium Ginger Beer",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d198",
    "name": "Pink Grapefruit Soda",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d199",
    "name": "Lemon Tonic Water",
    "category": "Premium-Softdrinks - Fever-Tree",
    "price": 3.9,
    "size": "0,2 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d200",
    "name": "Voelkel BioZisch Ingwer",
    "category": "Premium-Softdrinks - Voelkel",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d201",
    "name": "Voelkel BioZisch Blutorange",
    "category": "Premium-Softdrinks - Voelkel",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d202",
    "name": "Voelkel BioZisch Holunderblüte",
    "category": "Premium-Softdrinks - Voelkel",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d203",
    "name": "Voelkel BioZisch Maracuja Orange Light",
    "category": "Premium-Softdrinks - Voelkel",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d204",
    "name": "Voelkel BioZisch Himbeer Cassis Light",
    "category": "Premium-Softdrinks - Voelkel",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d205",
    "name": "ChariTea Mint ohne Zucker",
    "category": "Premium-Softdrinks",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d206",
    "name": "Kombucha Original",
    "category": "Premium-Softdrinks",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d207",
    "name": "Kombucha Sauerkirsche Minze",
    "category": "Premium-Softdrinks",
    "price": 3.9,
    "size": "0,33 l",
    "packages": {
      "all_in": "included",
      "fun": "excluded",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d208",
    "name": "Cappuccino",
    "category": "Heißgetränke - Kaffee",
    "price": 4.1,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d209",
    "name": "Milchkaffee",
    "category": "Heißgetränke - Kaffee",
    "price": 4.1,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d210",
    "name": "Kaffee",
    "category": "Heißgetränke - Kaffee",
    "price": 2.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d211",
    "name": "Entkoffeinierter Kaffee",
    "category": "Heißgetränke - Kaffee",
    "price": 2.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d212",
    "name": "Doppelter Espresso",
    "category": "Heißgetränke - Kaffee",
    "price": 3.6,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d213",
    "name": "Espresso Macchiato",
    "category": "Heißgetränke - Kaffee",
    "price": 2.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d214",
    "name": "Espresso",
    "category": "Heißgetränke - Kaffee",
    "price": 2.2,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d215",
    "name": "Latte Macchiato",
    "category": "Heißgetränke - Kaffee",
    "price": 4.1,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "excluded",
      "kids_fun": "excluded"
    },
    "note": "",
    "favorite": true,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d216",
    "name": "Heiße Schokolade",
    "category": "Heißgetränke",
    "price": 2.9,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d217",
    "name": "Kakao",
    "category": "Heißgetränke",
    "price": 1.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "Laut Barkarte nur für Kinder",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d218",
    "name": "Flavor-Zusatz Karamell/Macadamia/Vanille",
    "category": "Heißgetränke - Zusatz",
    "price": 0.5,
    "size": "",
    "packages": {
      "all_in": "unclear",
      "fun": "unclear",
      "kids_all_in": "unclear",
      "kids_fun": "unclear"
    },
    "note": "Zusatz/Flavor; Paketzuordnung nicht eindeutig",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d219",
    "name": "Bio Darjeeling Grün",
    "category": "Heißgetränke - Tee",
    "price": 3.4,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d220",
    "name": "Bio Früchte Natur",
    "category": "Heißgetränke - Tee",
    "price": 3.4,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d221",
    "name": "Assam Special Broken",
    "category": "Heißgetränke - Tee",
    "price": 3.4,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d222",
    "name": "Pfefferminze",
    "category": "Heißgetränke - Tee",
    "price": 3.4,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d223",
    "name": "Earl Grey",
    "category": "Heißgetränke - Tee",
    "price": 3.4,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d224",
    "name": "Tea Spa Magica",
    "category": "Heißgetränke - Tee",
    "price": 3.4,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d225",
    "name": "Alwine",
    "category": "Kids & Teens Cocktails",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d226",
    "name": "Itzi",
    "category": "Kids & Teens Cocktails",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d227",
    "name": "Dodo",
    "category": "Kids & Teens Cocktails",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d228",
    "name": "Achwasachwas",
    "category": "Kids & Teens Cocktails",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d229",
    "name": "Erdbeer-Milchshake",
    "category": "Kids & Teens Milchshakes",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d230",
    "name": "Vanille-Milchshake",
    "category": "Kids & Teens Milchshakes",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d231",
    "name": "Bananen-Milchshake",
    "category": "Kids & Teens Milchshakes",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  },
  {
    "id": "d232",
    "name": "Schokoladen-Milchshake",
    "category": "Kids & Teens Milchshakes",
    "price": 5.5,
    "size": "",
    "packages": {
      "all_in": "included",
      "fun": "included",
      "kids_all_in": "included",
      "kids_fun": "included"
    },
    "note": "",
    "favorite": false,
    "source": "AIDA Barkarte 01.11.2025"
  }
];
const AIDA_PACKAGES = [
  {
    "id": "none",
    "name": "Kein Paket",
    "age": "-",
    "description": "Keine automatische Paketabdeckung."
  },
  {
    "id": "all_in",
    "name": "ALL IN",
    "age": "ab 18 Jahren",
    "description": "Umfangreiches Paket mit alkoholischen und alkoholfreien Barkartengetränken laut Tabelle."
  },
  {
    "id": "fun",
    "name": "FUN",
    "age": "ab 16 Jahren",
    "description": "Alkoholfreier bzw. eingeschränkter Umfang laut Tabelle."
  },
  {
    "id": "kids_all_in",
    "name": "Kids & Teens ALL IN",
    "age": "4-17 Jahre",
    "description": "Kinder-/Jugendpaket mit Softdrinks, Heißgetränken, Kids-Getränken und Juicy Cocktails laut Tabelle."
  },
  {
    "id": "kids_fun",
    "name": "Kids & Teens FUN",
    "age": "4-17 Jahre",
    "description": "Kinder-/Jugendpaket mit Softdrinks, Heißgetränken und Kids-Getränken laut Tabelle."
  }
];
